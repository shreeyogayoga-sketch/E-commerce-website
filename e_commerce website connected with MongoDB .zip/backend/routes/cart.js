const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const User = require('../models/User');
const Product = require('../models/Product');

// Get cart
router.get('/', auth, async (req, res) => {
  const user = await User.findById(req.user.id).populate('cart.product');
  res.json(user.cart);
});

// Add to cart and update stock
router.post('/add', auth, async (req, res) => {
  const { productId, quantity } = req.body;
  try {
    const product = await Product.findById(productId);
    if (!product) return res.status(404).json({ msg: 'Product not found' });
    if (product.stock < quantity) return res.status(400).json({ msg: 'Not enough stock available' });

    const user = await User.findById(req.user.id);
    const existingItem = user.cart.find(item => item.product.toString() === productId);
    if (existingItem) {
      existingItem.quantity += quantity;
    } else {
      user.cart.push({ product: productId, quantity });
    }
    await user.save();

    // Decrease stock
    product.stock -= quantity;
    await product.save();

    res.json(user.cart);
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
});

// Remove from cart and restore stock
router.post('/remove', auth, async (req, res) => {
  const { productId } = req.body;
  try {
    const user = await User.findById(req.user.id);
    const itemIndex = user.cart.findIndex(item => item.product.toString() === productId);
    if (itemIndex === -1) return res.status(404).json({ msg: 'Item not in cart' });

    const item = user.cart[itemIndex];
    user.cart.splice(itemIndex, 1);
    await user.save();

    // Restore stock
    const product = await Product.findById(productId);
    if (product) {
      product.stock += item.quantity;
      await product.save();
    }

    res.json(user.cart);
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
});

// Update cart item quantity (adjust stock accordingly)
router.post('/update', auth, async (req, res) => {
  const { productId, quantity } = req.body;
  try {
    const user = await User.findById(req.user.id);
    const item = user.cart.find(item => item.product.toString() === productId);
    if (!item) return res.status(404).json({ msg: 'Item not found' });

    const product = await Product.findById(productId);
    if (!product) return res.status(404).json({ msg: 'Product not found' });

    // Restore old stock first
    product.stock += item.quantity;

    // Check if enough stock for new quantity
    if (product.stock < quantity) return res.status(400).json({ msg: 'Not enough stock available' });

    // Apply new quantity and adjust stock
    item.quantity = quantity;
    product.stock -= quantity;

    await user.save();
    await product.save();

    res.json(user.cart);
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
});

module.exports = router;
