const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Register
router.post('/register', async (req, res) => {
  const { name, email, password, address, adminSecret } = req.body;
  try{
    let user = await User.findOne({ email });
    if(user) return res.status(400).json({ msg: 'User already exists' });
    const salt = await bcrypt.genSalt(10);
    const hash = await bcrypt.hash(password, salt);
    // Admin if secret matches "admin"
    const isAdmin = adminSecret && adminSecret === "admin";
    user = new User({ name, email, password: hash, address, isAdmin });
    await user.save();
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET || 'secretkey', { expiresIn: '7d' });
    res.json({ token, user: { id: user._id, name: user.name, email: user.email, address: user.address, isAdmin: user.isAdmin }});
  }catch(err){
    console.error(err);
    res.status(500).send('Server error');
  }
});

// Login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  try{
    const user = await User.findOne({ email });
    if(!user) return res.status(400).json({ msg: 'Invalid credentials' });
    const isMatch = await bcrypt.compare(password, user.password);
    if(!isMatch) return res.status(400).json({ msg: 'Invalid credentials' });
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET || 'secretkey', { expiresIn: '7d' });
    res.json({ token, user: { id: user._id, name: user.name, email: user.email, address: user.address, isAdmin: user.isAdmin }});
  }catch(err){
    console.error(err);
    res.status(500).send('Server error');
  }
});

// Get current user
router.get('/me', async (req, res) => {
  const token = req.header('Authorization')?.replace('Bearer ','') || '';
  if(!token) return res.status(401).json({ msg: 'No token' });
  try{
    const decoded = require('jsonwebtoken').verify(token, process.env.JWT_SECRET || 'secretkey');
    const user = await require('../models/User').findById(decoded.id).select('-password');
    res.json(user);
  }catch(err){ res.status(401).json({ msg: 'Invalid token' }); }
});

// Update profile
router.post('/update', async (req, res) => {
  const token = req.header('Authorization')?.replace('Bearer ','') || '';
  if(!token) return res.status(401).json({ msg: 'No token' });
  try{
    const decoded = require('jsonwebtoken').verify(token, process.env.JWT_SECRET || 'secretkey');
    const user = await require('../models/User').findById(decoded.id);
    if(req.body.name) user.name = req.body.name;
    if(req.body.address) user.address = req.body.address;
    await user.save();
    res.json({ msg: 'Updated' });
  }catch(err){ res.status(401).json({ msg: 'Invalid token' }); }
});

// Delete account
router.delete('/delete', async (req, res) => {
  const token = req.header('Authorization')?.replace('Bearer ','') || '';
  if(!token) return res.status(401).json({ msg: 'No token' });
  try{
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'secretkey');
    const user = await User.findById(decoded.id);
    if(!user) return res.status(404).json({ msg: 'User not found' });
    await user.deleteOne();
    res.json({ msg: 'Account deleted' });
  }catch(err){
    res.status(401).json({ msg: 'Invalid token' });
  }
});

module.exports = router;
