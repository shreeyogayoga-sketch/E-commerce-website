const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Order = require('../models/Order');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY || 'sk_test_key');

// Create order (checkout)
router.post('/checkout', auth, async (req, res) => {
  const { paymentMethod, address } = req.body;
  // Build items from user's cart
  await req.user.populate('cart.product');
  const items = req.user.cart.map(ci => ({
    product: ci.product._id,
    quantity: ci.quantity,
    price: ci.product.price
  }));
  const total = items.reduce((s,it)=> s + it.price*it.quantity, 0);
  // For demo: pretend to create charge via Stripe (no real payment processed without real key)
  let paymentStatus = 'pending';
  if(paymentMethod === 'stripe'){
    try{
      // Create a PaymentIntent (demo)
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(total * 100),
        currency: 'usd',
        payment_method_types: ['card'],
      });
      paymentStatus = 'paid';
    }catch(err){
      console.error('stripe error', err);
      paymentStatus = 'failed';
    }
  } else {
    paymentStatus = 'paid'; // cash on delivery or other methods in demo
  }
  const order = new Order({
    user: req.user._id,
    items, total,
    paymentMethod, paymentStatus, address: address || req.user.address
  });
  await order.save();
  // Clear cart
  req.user.cart = [];
  await req.user.save();
  res.json(order);
});

// Get orders for user
router.get('/', auth, async (req, res) => {
  const orders = await Order.find({ user: req.user._id }).populate('items.product');
  res.json(orders);
});

module.exports = router;
