const express = require('express');
const router = express.Router();
const Product = require('../models/Product');
const auth = require('../middleware/auth');

// Create product (admin only)
router.post('/', auth, async (req, res) => {
  if(!req.user || !req.user.isAdmin) return res.status(403).json({ msg: 'Admin only' });
  try{
    const p = new Product(req.body);
    await p.save();
    res.json(p);
  }catch(err){ res.status(500).send('Server error'); }
});

// Read all
router.get('/', async (req, res) => {
  const items = await Product.find();
  res.json(items);
});

// Read one
router.get('/:id', async (req, res) => {
  const item = await Product.findById(req.params.id);
  res.json(item);
});

// Update (admin only)
router.put('/:id', auth, async (req, res) => {
  if(!req.user || !req.user.isAdmin) return res.status(403).json({ msg: 'Admin only' });
  const updated = await Product.findByIdAndUpdate(req.params.id, req.body, { new:true });
  res.json(updated);
});

// Delete (admin only)
router.delete('/:id', auth, async (req, res) => {
  if(!req.user || !req.user.isAdmin) return res.status(403).json({ msg: 'Admin only' });
  await Product.findByIdAndDelete(req.params.id);
  res.json({ msg: 'Deleted' });
});

module.exports = router;
