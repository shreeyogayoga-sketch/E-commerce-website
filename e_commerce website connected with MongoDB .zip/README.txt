E-commerce MERN-like project (minimal demo)
------------------------------------------
Structure:
- backend/ : Node.js + Express + MongoDB (Mongoose)
- frontend/: React (Vite)

Setup (locally):
1. Install MongoDB and make sure it's running.
2. Backend:
   cd backend
   npm install
   copy .env.example to .env and fill MONGO_URI and JWT_SECRET (and STRIPE key if using)
   npm run dev
3. Frontend:
   cd frontend
   npm install
   npm run dev
4. Seed products by creating products via POST /api/products (use Postman or create a small script)

Notes:
- Authentication uses JWT stored in localStorage for demo purposes.
- Payment integration with Stripe is a placeholder — you'll need real API keys and frontend Stripe integration for card payments.
- This is a demo starter; add validation, error handling, admin roles, and production configs before deploying.
