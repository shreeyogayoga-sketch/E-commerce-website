E-Commerce Project Patch: Stock Update & Logout Button
------------------------------------------------------

This patch contains two modified files to update your project.

1. backend/routes/cart.js
   - Updates product stock when adding to cart (decreases stock).
   - Restores product stock when removing from cart.
   - Adjusts stock correctly when updating cart item quantity.

2. frontend/src/components/Navbar.jsx
   - Adds a Logout button on the top-right of the navigation bar.
   - Clicking Logout clears localStorage and redirects to /login.

How to apply this patch:
------------------------
1. Copy cart.js into your project at:
   e_commerce_mongo_project/backend/routes/cart.js

2. Copy Navbar.jsx into your project at:
   e_commerce_mongo_project/frontend/src/components/Navbar.jsx

3. Restart both backend and frontend servers:
   Backend:
     cd backend
     npm run dev
   Frontend:
     cd frontend
     npm run dev

Now your project will:
- Update product stock when users add/remove items from the cart.
- Show a Logout button in the navigation bar (top right).
