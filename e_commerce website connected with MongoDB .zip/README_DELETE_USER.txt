New Features
------------
1. Admin role is assigned if "admin" is entered in the Admin Secret field during registration.
2. Users can delete their own account via the Profile page (/profile).

Changes:
- Backend /api/auth/delete route removes current user account.
- Frontend Profile page has a Delete Account button that calls this route.

How to create an admin user:
- When registering, enter "admin" in the Admin Secret field. That user will have isAdmin=true.
