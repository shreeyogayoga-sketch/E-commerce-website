Admin Frontend Added
-------------------
This frontend includes an Admin page at /admin where an authenticated user can:
- Create products (POST /api/products)
- Edit products (PUT /api/products/:id)
- Delete products (DELETE /api/products/:id)

Authentication:
- The backend requires a valid JWT for product create/update/delete. Use /api/auth/register then /api/auth/login to get a token and put it into localStorage as 'token' (the app's Login does this automatically).

How to run:
1. Start backend (make sure MongoDB is running):
   cd backend
   npm install
   npm run dev
2. Start frontend:
   cd frontend
   npm install
   npm run dev
3. Open http://localhost:5173 and go to Admin to manage products.

Note: This is a simple demo. Add validation and admin role checks before using in production.
