Project with Admin role and protected product CRUD
-------------------------------------------------
Changes made:
- User model now has 'isAdmin' boolean.
- Register endpoint accepts 'adminSecret' (must match ADMIN_SECRET in backend .env) to create admin user.
- Product create/update/delete routes are protected and only allowed for admin users (auth middleware checks req.user.isAdmin).
- Frontend Admin page fetches /api/auth/me to verify admin access and shows 'Access denied' for non-admins.
- Login/Register store 'user' in localStorage for convenience.

How to create an admin user:
1. In backend/.env set ADMIN_SECRET to a strong secret.
2. Register a user via the frontend register form and enter the same admin secret in the 'Admin secret' field.
3. That user will be created with isAdmin=true and can use /admin to manage products.

How to run:
1. Start MongoDB.
2. Backend:
   cd backend
   npm install
   copy .env.example to .env and set MONGO_URI, JWT_SECRET, ADMIN_SECRET
   npm run dev
3. Frontend:
   cd frontend
   npm install
   npm run dev
4. Open http://localhost:5173

Notes:
- For production, implement stricter admin creation flows, add validation, and avoid storing JWT in localStorage.
