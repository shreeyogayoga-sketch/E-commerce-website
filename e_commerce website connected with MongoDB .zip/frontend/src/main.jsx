import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'
import Home from './pages/Home'
import Login from './pages/Login'
import Register from './pages/Register'
import Cart from './pages/Cart'
import Profile from './pages/Profile'
import Checkout from './pages/Checkout'
import Admin from './pages/Admin'

function App(){
  const token = localStorage.getItem('token');
  return (
    <BrowserRouter>
      <nav style={{padding:10, borderBottom:'1px solid #ccc'}}>
        <Link to="/">Home</Link> | <Link to="/cart">Cart</Link> | <Link to="/admin">Admin</Link> | {token ? <Link to="/profile">Profile</Link> : <Link to="/login">Login</Link>}
      </nav>
      <Routes>
        <Route path="/" element={<Home/>}/>
        <Route path="/login" element={<Login/>}/>
        <Route path="/register" element={<Register/>}/>
        <Route path="/cart" element={<Cart/>}/>
        <Route path="/profile" element={<Profile/>}/>
        <Route path="/checkout" element={<Checkout/>}/>
        <Route path="/admin" element={<Admin/>}/>
      </Routes>
    </BrowserRouter>
  )
}

createRoot(document.getElementById('root')).render(<App />)
