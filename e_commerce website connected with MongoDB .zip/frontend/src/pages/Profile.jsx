import React, {useEffect, useState} from 'react';

export default function Profile(){
  const [user, setUser] = useState(null);
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const token = localStorage.getItem('token');
  useEffect(()=> {
    const fetchUser = async () => {
      const res = await fetch('http://localhost:5000/api/auth/me', { headers: { Authorization: 'Bearer '+token }});
      if(res.ok){
        const data = await res.json();
        setUser(data);
        setName(data.name);
        setAddress(data.address || '');
      }
    }
    fetchUser();
  },[]);
  const save = async () => {
    await fetch('http://localhost:5000/api/auth/update', {
      method:'POST', headers:{'Content-Type':'application/json', Authorization: 'Bearer '+token},
      body: JSON.stringify({ name, address })
    });
    alert('Profile updated (refresh to see changes)');
  }
  const logout = ()=> { localStorage.removeItem('token'); localStorage.removeItem('user'); window.location.href = '/'; }
  const deleteAccount = async () => {
    if(!window.confirm('Are you sure you want to delete your account? This cannot be undone.')) return;
    const res = await fetch('http://localhost:5000/api/auth/delete', { method:'DELETE', headers: { Authorization: 'Bearer '+token } });
    if(res.ok){
      alert('Account deleted');
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/';
    } else {
      alert('Failed to delete account');
    }
  }
  if(!user) return <div style={{padding:20}}>Loading...</div>
  return (
    <div style={{padding:20}}>
      <h2>Profile</h2>
      <p>Email: {user.email}</p>
      <input value={name} onChange={e=>setName(e.target.value)} placeholder="Name"/><br/>
      <textarea value={address} onChange={e=>setAddress(e.target.value)} placeholder="Address"></textarea><br/>
      <button onClick={save}>Save</button> <button onClick={logout}>Logout</button> <button onClick={deleteAccount}>Delete Account</button>
    </div>
  )
}
