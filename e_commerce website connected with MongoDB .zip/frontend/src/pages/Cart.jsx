import React, {useEffect, useState} from 'react';
import { Link, useNavigate } from 'react-router-dom';

export default function Cart(){
  const [cart, setCart] = useState([]);
  const nav = useNavigate();
  const token = localStorage.getItem('token');
  useEffect(()=> {
    fetch('http://localhost:5000/api/cart', { headers: { Authorization: 'Bearer '+token } })
      .then(r=>r.json()).then(setCart);
  },[]);
  const remove = async (id) => {
    await fetch('http://localhost:5000/api/cart/remove', { method:'POST', headers:{'Content-Type':'application/json', Authorization: 'Bearer '+token}, body: JSON.stringify({ productId: id })});
    setCart(cart.filter(ci=>ci.product._id !== id));
  }
  const total = cart.reduce((s,ci)=> s + (ci.product.price * ci.quantity), 0);
  return (
    <div style={{padding:20}}>
      <h2>Cart</h2>
      {cart.length===0 ? <p>Cart is empty</p> : (
        <>
          {cart.map(ci=>(
            <div key={ci.product._id} style={{border:'1px solid #ddd', padding:10, marginBottom:8}}>
              <h4>{ci.product.title}</h4>
              {ci.product.image && <img src={ci.product.image} alt={ci.product.title} style={{width:120}}/>}
              <p>Qty: {ci.quantity} | Price: ${ci.product.price}</p>
              <button onClick={()=>remove(ci.product._id)}>Remove</button>
            </div>
          ))}
          <h3>Total: ${total}</h3>
          <button onClick={()=>nav('/checkout')}>Checkout</button>
        </>
      )}
    </div>
  );
}
