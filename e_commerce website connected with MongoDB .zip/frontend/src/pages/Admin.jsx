import React, {useEffect, useState} from 'react';

export default function Admin(){
  const [products, setProducts] = useState([]);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ title:'', description:'', price:0, image:'', category:'', stock:0 });
  const [user, setUser] = useState(null);
  const token = localStorage.getItem('token');

  const load = async () => {
    const res = await fetch('http://localhost:5000/api/products');
    const data = await res.json();
    setProducts(data);
  }

  useEffect(()=> {
    const fetchUser = async () => {
      if(!token) return;
      const res = await fetch('http://localhost:5000/api/auth/me', { headers: { Authorization: 'Bearer '+token }});
      if(res.ok){
        const u = await res.json();
        setUser(u);
      }
    }
    fetchUser();
    load();
  },[]);

  if(user && !user.isAdmin){
    return <div style={{padding:20}}>Access denied — you are not an admin.</div>
  }

  const startEdit = (p) => { setEditing(p._id); setForm({ title:p.title, description:p.description, price:p.price, image:p.image||'', category:p.category||'', stock:p.stock||0 }); }
  const cancel = () => { setEditing(null); setForm({ title:'', description:'', price:0, image:'', category:'', stock:0 }); }

  const save = async () => {
    if(!token){ alert('Login required'); return; }
    if(editing){
      await fetch('http://localhost:5000/api/products/' + editing, {
        method:'PUT', headers: {'Content-Type':'application/json', Authorization: 'Bearer '+token},
        body: JSON.stringify(form)
      });
      setEditing(null);
    } else {
      await fetch('http://localhost:5000/api/products', {
        method:'POST', headers: {'Content-Type':'application/json', Authorization: 'Bearer '+token},
        body: JSON.stringify(form)
      });
    }
    setForm({ title:'', description:'', price:0, image:'', category:'', stock:0 });
    load();
  }

  const remove = async (id) => {
    if(!confirm('Delete product?')) return;
    await fetch('http://localhost:5000/api/products/' + id, { method:'DELETE', headers: { Authorization: 'Bearer '+token } });
    load();
  }

  return (
    <div style={{padding:20}}>
      <h2>Admin - Products CRUD</h2>
      <div style={{display:'flex', gap:20}}>
        <div style={{flex:1}}>
          <h3>{editing ? 'Edit product' : 'Add new product'}</h3>
          <input placeholder="Title" value={form.title} onChange={e=>setForm({...form, title:e.target.value})} /><br/>
          <textarea placeholder="Description" value={form.description} onChange={e=>setForm({...form, description:e.target.value})} /><br/>
          <input placeholder="Price" type="number" value={form.price} onChange={e=>setForm({...form, price: Number(e.target.value)})} /><br/>
          <input placeholder="Image URL" value={form.image} onChange={e=>setForm({...form, image:e.target.value})} /><br/>
          <input placeholder="Category" value={form.category} onChange={e=>setForm({...form, category:e.target.value})} /><br/>
          <input placeholder="Stock" type="number" value={form.stock} onChange={e=>setForm({...form, stock: Number(e.target.value)})} /><br/>
          <button onClick={save}>{editing ? 'Update' : 'Create'}</button> <button onClick={cancel}>Clear</button>
        </div>
        <div style={{flex:2}}>
          <h3>Products</h3>
          {products.map(p => (
            <div key={p._id} style={{border:'1px solid #ddd', padding:10, marginBottom:8}}>
              <strong>{p.title}</strong> - ${p.price} <br/>
              <small>{p.category} | Stock: {p.stock}</small>
              <div style={{marginTop:8}}>
                <button onClick={()=>startEdit(p)}>Edit</button> <button onClick={()=>remove(p._id)}>Delete</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
