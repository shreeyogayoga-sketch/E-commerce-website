import React, {useEffect, useState} from 'react';

export default function Home(){
  const [products, setProducts] = useState([]);
  useEffect(()=> {
    fetch('http://localhost:5000/api/products')
      .then(r=>r.json()).then(setProducts);
  },[]);
  const addToCart = async (id) => {
    const token = localStorage.getItem('token');
    await fetch('http://localhost:5000/api/cart/add', {
      method:'POST', headers: {'Content-Type':'application/json', Authorization: 'Bearer '+token},
      body: JSON.stringify({ productId: id, quantity:1 })
    });
    alert('Added to cart');
  }
  return (
    <div style={{padding:20}}>
      <h2>Products</h2>
      <div style={{display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:10}}>
        {products.map(p=>(
          <div key={p._id} style={{border:'1px solid #ddd', padding:10}}>
            <h3>{p.title}</h3>
            {p.image && <img src={p.image} alt={p.title} style={{width:'100%', maxHeight:150, objectFit:'cover'}}/>}
            <p>{p.description}</p>
            <p>Price: ${p.price}</p>
            <button onClick={()=>addToCart(p._id)}>Add to cart</button>
          </div>
        ))}
      </div>
    </div>
  );
}
