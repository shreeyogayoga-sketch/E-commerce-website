import React, {useState} from 'react'
import { useNavigate } from 'react-router-dom';

export default function Register(){
  const [name,setName]=useState(''); const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [adminSecret,setAdminSecret]=useState('');
  const nav = useNavigate();
  const submit = async e => {
    e.preventDefault();
    const res = await fetch('http://localhost:5000/api/auth/register', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ name, email, password, adminSecret })
    });
    const data = await res.json();
    if(data.token){
      localStorage.setItem('token', data.token);
      localStorage.setItem('user', JSON.stringify(data.user || {}));
      nav('/');
    } else {
      alert(data.msg || 'Register failed');
    }
  }
  return (
    <div style={{padding:20}}>
      <h2>Register</h2>
      <form onSubmit={submit}>
        <input value={name} onChange={e=>setName(e.target.value)} placeholder="Name"/><br/>
        <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email"/><br/>
        <input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password"/><br/>
        <input value={adminSecret} onChange={e=>setAdminSecret(e.target.value)} placeholder="Admin secret (optional)"/><br/>
        <button type="submit">Register</button>
      </form>
    </div>
  )
}
