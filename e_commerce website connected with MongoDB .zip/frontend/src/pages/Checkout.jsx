import React, {useState} from 'react';
import { useNavigate } from 'react-router-dom';
export default function Checkout(){
  const [address, setAddress] = useState('');
  const token = localStorage.getItem('token');
  const nav = useNavigate();
  const checkout = async () => {
    const res = await fetch('http://localhost:5000/api/orders/checkout', {
      method:'POST', headers:{'Content-Type':'application/json', Authorization: 'Bearer '+token},
      body: JSON.stringify({ paymentMethod: 'cod', address })
    });
    const data = await res.json();
    alert('Order placed: ' + data._id);
    nav('/');
  }
  return (
    <div style={{padding:20}}>
      <h2>Checkout</h2>
      <textarea placeholder="Shipping address" value={address} onChange={e=>setAddress(e.target.value)} /><br/>
      <button onClick={checkout}>Place order (Cash on Delivery)</button>
    </div>
  );
}
